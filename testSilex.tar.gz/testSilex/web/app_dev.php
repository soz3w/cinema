<?php
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

require_once __DIR__.'/../vendor/autoload.php';
$app = new Silex\Application();
$app['debug'] = true;
$app->register(new Silex\Provider\TwigServiceProvider(), array(
    'twig.path' => __DIR__.'/views',
));

$app->get('/hello/{name}', function ($name) use ($app) {
    return $app['twig']->render('hello.twig', array(
        'name' => $name,
    ));
});

$app->get('/hello/{name}', function ($name) use ($app) {
    return 'Hello '.$app->escape($name);  //contre l'injection
});

$movies = array(
    1 => array(
        'date' => '2011-03-29',
        'author' => 'igorw',
        'title' => 'Film1',
        'body' => 'loremfhgfhgfhfhgfhgfhgfhg',
    ),
    2 => array(
        'date' => '2011-03-29',
        'author' => 'igorw',
        'title' => 'Film2',
        'body' => 'AAAAAAAAAAAAAAAAAAAAAAAA',
    ),
    3 => array(
        'date' => '2011-03-29',
        'author' => 'igorw',
        'title' => 'Film3',
        'body' => 'nfjkdfkldfdfmmmmmmmmmmmmmmmmmmmm',
    ),
);
$app->get('/movies', function () use ($movies) {
    $output = '';
    foreach ($movies as $movie) {
        $output .= $movie['title'];
        $output .= '<br />';
    }
    return $output;
});


//paramconverter comme symfony pour id!

$app->get('/user/{id}', function ($id) {
    // ...
})->convert('id', function ($id) { return (int) $id; });


$app->get('/movie/{id}', function (Silex\Application $app, $id) use ($movies) {
    if (!isset($movies[$id])) {
        $app->abort(404, "Movie $id does not exist.");
    }
    $movie = $movies[$id];
    return "<h1>{$movie['title']}</h1>".
    "<p>{$movie['body']}</p>";
})->assert('id', '\d+')
->value('id', '1')  //valeur par defaut
    ->bind('movie_get'); //name for my route

$app->put('/blog/{id}', function ($id) {
    // ...
});

$app->delete('/blog/{id}', function ($id) {
    // ...
});


$app->post('/feedback', function (Request $request) {
    $message = $request->get('message');
    mail('feedback@yoursite.com', '[YourSite] Feedback', $message);

    return new Response('Thank you for your feedback!', 201);
});


$app->run();